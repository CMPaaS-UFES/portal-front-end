export class User {
    _id: String;
    name: String;
    surname: String;
    password: String;
    email: String;
    link: Object;
}