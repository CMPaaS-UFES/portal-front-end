import { Injectable } from '@angular/core';
import { authApiUri } from '../../global.vars';
import { User } from '../../_models/user.model';
import { HttpClient } from '@angular/common/http';

export const TOKEN_NAME: String = 'token';

@Injectable()
export class AuthService {
    private _currentUser: User;

    constructor(private http: HttpClient){}

    isAuthenticated(){
        
    }

    login(){
        console.log(authApiUri);
        this.http.post(authApiUri, {
            username: 'wagnerperin',
            password: '1234'
        }).subscribe(
            data=> console.log(data),
            err => console.log(err)
        )
            
    }
}